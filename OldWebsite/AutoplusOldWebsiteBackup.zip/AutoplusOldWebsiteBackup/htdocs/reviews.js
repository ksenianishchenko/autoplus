
	reviews = [
   {
      "review":"Fixed right the first time",
      "person":"Harris S. in Manteca",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:O1JdCUoHqjVGoYg6N_jLHA"
   },
   {
      "review":"Detailed information, options, and reasonable pricing",
      "person":"Jason H. in Oakland",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:HpY-qcmlHao33bBaDgcQBQ"
   },
   {
      "review":"I'm extremely grateful for the fair and kind customer service that I get every single time",
      "person":"Jana C. on Yelp",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:zCBlVhMz5dT3FWLLg8kysg"
   },
   {
      "review":"I appreciate the time taken to explain clearly the details of what work will go in, the fair prices, and the convenience to El Cerrito Plaza for the downtime distraction.",
      "person":"Jana C. on Yelp",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:zCBlVhMz5dT3FWLLg8kysg"
   },
   {
      "review":"Love their work ethic",
      "person":"Jana C. on Yelp",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:zCBlVhMz5dT3FWLLg8kysg"
   },
   {
      "review":"I'm extremely grateful for the fair and kind customer service that I get every single time i service my Passat with Naim and Ali and co.",
      "person":"Jana C. on Yelp",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:zCBlVhMz5dT3FWLLg8kysg"
   },
   {
      "review":"This brother duo has kept my car far out of trouble and in good condition. I appreciate the time taken to explain clearly the details of what work will go in, the fair prices, and the convenience to El Cerrito Plaza for the downtime distraction.",
      "person":"Jana C. on Yelp",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:zCBlVhMz5dT3FWLLg8kysg"
   },
   {
      "review":"THE BEST MECHANIC IN THE BAY AREA: i've been to alot of mechanics and most of them turned out to be swindlers. But my friend who fixes cars, recommended Naim at Auto Plus. So I went. I've been with him for 4 years now. ",
      "person":"Say Y. in Santa Clara",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:4b72640gLH_kMtEcTyCofg"
   },
   {
      "review":"He's ALWAYS HONEST & VERY AFFORDABLE. He has all his prices and work he'll do clearly printed on a brochure, so you know he's not changing the price or the work judging by your car.",
      "person":"Say Y. in Santa Clara",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:4b72640gLH_kMtEcTyCofg"
   },
   {
      "review":"THE BEST MECHANIC IN THE BAY AREA",
      "person":"Say Y. in Santa Clara",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:4b72640gLH_kMtEcTyCofg"
   },
   {
      "review":"ALWAYS HONEST & VERY AFFORDABLE",
      "person":"Say Y. in Santa Clara",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:4b72640gLH_kMtEcTyCofg"
   },
   {
      "review":"If you need maintenance, timing belt replacement, or you car has problems, go to AUTO PLUS!",
      "person":"Say Y. in Santa Clara",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:4b72640gLH_kMtEcTyCofg"
   },
   {
      "review":"Auto Plus is an honest and competitively priced shop to take your Volkswagen/ Audi or Mercedes for almost all of your repairs and maintenance.",
      "person":"Barron L. on Yelp",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:BM667D1OpsijQlqf41QcQw"
   },
   {
      "review":"Auto Plus is an honest and competitively priced shop to take your Volkswagen/ Audi or Mercedes for almost all of your repairs and maintenance.  ",
      "person":"Barron L. on Yelp",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:BM667D1OpsijQlqf41QcQw"
   },
   {
      "review":"For the past two years, they've performed oil changes, minor/major scheduled maintenance, brake and rotor replacement and timing belt replacement.  They do a good job of explaining why they do what they do and often show you the old/worn part afterwards.  Depending on the job, they'll offer a range of parts to accommodate your budget (e.g. OEM vs. high-performance parts) and I've never felt I was being pressured to purchase anything I didn't want or need.",
      "person":"Barron L. on Yelp",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:BM667D1OpsijQlqf41QcQw"
   },
   {
      "review":"Very kind and honest",
      "person":"Anton W. in Albany",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:FVvRb37A--x44-GYC7l5rw"
   },
   {
      "review":"This is an excellent and reasonable garage, and if something is easy to do in addition to the work they are already doing they will do it as a courtesy to you!",
      "person":"Daniel G. in Berkeley",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:p_ACaAus6HYtZMpZf-7CFA"
   },
   {
      "review":"There was no pressure from any of the mechanics to do any services with them. They really provided fair and honest opinions of any services for the car. They are great people! I highly recommend them.",
      "person":"Anton W. in Albany",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:FVvRb37A--x44-GYC7l5rw"
   },
   {
      "review":"Highly recommend; fair pricing as well as excellent work.",
      "person":"Thomas G. in Richmond",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:Go0vPxNkET0euZ12EA7Jrg"
   },
   {
      "review":"Fixing my car satisfactorily for over 7 years",
      "person":"Alotta F. in Oakland",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:EFlQ_IpNVY_3k8pr6X8m6g"
   },
   {
      "review":"VERY kind and helpful",
      "person":"Alotta F. in Oakland",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:EFlQ_IpNVY_3k8pr6X8m6g"
   },
   {
      "review":"They are VERY kind and helpful. When they replace parts, they usually show me the damaged one and explained why they had to replace it. They don't require appointments and on occasion they work on saturdays, but call and ask to be sure. I've never had to bring my car back because they didn't fix something right the first time and I've never felt as if I was being taken advantage of. The brothers are a little shy and soft spoken so they may come across as shifty but worry not. They are hard working and honest. I've only ever seen Ieme working on the cars (Ali does the bookkeeping) and I think he's able to fix about 3-5 a day alone! Impressive.",
      "person":"Alotta F. in Oakland",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:EFlQ_IpNVY_3k8pr6X8m6g"
   },
   {
      "review":"Super honest, do a great job for a great price.",
      "person":"Haris S. in Richmond",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:2kCMBe8IdMiqglCJp5E5VA"
   },
   {
      "review":"You'll be happy you came here!",
      "person":"Haris S. in Richmond",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:2kCMBe8IdMiqglCJp5E5VA"
   },
   {
      "review":"They've always been gracious and helpful",
      "person":"Bobbie D. in Kensington",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:Rz_BrdbuYdtwPsvdfMXSrA"
   },
   {
      "review":"I've been very satisfied with Auto Plus over the past 2 years that I've been taking my middle-aged Passat  to them. They have always returned my car to me in great shape for a fair price. Almost 100% of my business with them has been last minute, unexpected, drop-in, can you do it soon? Today? I'm stranded, etc. And they've always been gracious and helpful. Eg. the power window broke during the rainy season, just as I was locking up at 8:30am at El Cerrito Plaza BART...so I just drive a few blocks over there, and they accommodate me by 1) taking me back to BART so I'm not terribly late to work and 2) being finished by 5:30pm so I can pick up my kid on time.",
      "person":"Bobbie D. in Kensington",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:Rz_BrdbuYdtwPsvdfMXSrA"
   },
   {
      "review":"Their estimates are always within 5% of the final bill, they suggest work-arounds, tell you when you can wait to do something, and what to listen for to know if the waiting period is over.",
      "person":"Bobbie D. in Kensington",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:Rz_BrdbuYdtwPsvdfMXSrA"
   },
   {
      "review":"I like these guys--they have been fair and honest with me over multiple visits",
      "person":"Bobbie D. in Kensington",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:Rz_BrdbuYdtwPsvdfMXSrA"
   },
   {
      "review":"Excellent service.  My car just recently began acting as if the clutch was broken (appeared to slip in various gears).  The price on a clutch repair was going to be $600-$700.  After bringing it to Auto Plus, they drove it around and concluded it was in fact not the clutch.  Opened the hood, secured the distributor cap cables and voila, problem solved.  ",
      "person":"David R. in El Cerrito",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:ZkPuBAKI4ESSJJiskX92-Q"
   },
   {
      "review":"Thanks Auto Plus!",
      "person":"David R. in El Cerrito",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:ZkPuBAKI4ESSJJiskX92-Q"
   },
   {
      "review":"I've been bringing my car to Naim for several years. Being a woman, car maintenance can make you feel a little vulnerable and you don't really know who to trust. Naim has always been honest and his prices are very reasonable. I don't take my car to anyone else. Highly recommend Naim/Auto Plus.",
      "person":"Caligurl G. in San Francisco",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:e6YJhh6h1Go6YVKfZb61Rg"
   },
   {
      "review":"My ol' Jetta got excellent service at Auto Plus.  I can't remember the last time it ran this silky smooth.  On top of this, Naim provided an honest assess of services needed, which saved me a few hundred bucks compared to if I had gone with the advice of a certain dealership.  I urge you to give them a visit next time you need your ride cared for.",
      "person":"Paul A. in Albany",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:AlyTI7KSZr_4lXTbWu51Jw"
   },
   {
      "review":"Nice guys that are honest. I have been taking my cars here for a few years and I have no complaints.",
      "person":"Todd F. on Yelp",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:wTaS-sjOprDVYT-VJWD7FA"
   },
   {
      "review":"This place is amazing. They are super nice guys, they are honest about the work they need to put in and offer reasonable prices, and they know what they are doing! They're the only place I trust to fix my 1973 Super Beetle, after having tried several other mechanics who just do not understand how old cars work. I am ever grateful to them for their consistent hard work and pleasant demeanor!",
      "person":"Christa E. in Oakland",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:PSesVQiV7OgUzBxpmWHkMA"
   },
   {
      "review":"I am ever grateful to them",
      "person":"Christa E. in Oakland",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:PSesVQiV7OgUzBxpmWHkMA"
   },
   {
      "review":"This place is amazing.",
      "person":"Christa E. in Oakland",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:PSesVQiV7OgUzBxpmWHkMA"
   },
   {
      "review":"I urge you to give them a visit",
      "person":"Paul A. in Albany",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:AlyTI7KSZr_4lXTbWu51Jw"
   },
   {
      "review":"I have been a satisfied customer for the past 5 years. The two brothers who run this place and honest and they know what they are doing. When I took my car to other mechanics after a car crash, they gave me estimates of around $5000 but in Auto Plus, they repaired every thing in less than $3000. I have recommended them to my family and friends and they are all very happy to finally have a permanent mechanic. Auto Plus is located a block away from El Cerrito Plaza. If you request there is always someone to drop you to the Bart station or you can hang out in the Plaza while they fix your car.",
      "person":"Madina M. in El Cerrito",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:-sdoiZBEejtdWglicF7rIQ"
   },
   {
      "review":"High recommendations across the board",
      "person":"David B. in Berkeley",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:CHO56UXRsmf4rBMz0OZqkQ"
   },
   {
      "review":"I live in Chico, CA, and as I was headed home from the bay, my Volkswagen leaked all of its coolant at a gas station. I promptly called Auto Plus in Albany, and they said they would do what they could for my car. A few hours later, they called me back and told me exactly what I thought had happened: the water pump and the timing belt system on my Turbo Beetle needed to be replaced. What a shame, but they gave me a great price and got the repair finished in time the next day. Very friendly, honest, people!",
      "person":"Ansel L. in Durham",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:sxn3s7bRhUQfhEvud1M1qw"
   },
   {
      "review":"Very friendly, honest, people!",
      "person":"Ansel L. in Durham",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:sxn3s7bRhUQfhEvud1M1qw"
   },
   {
      "review":"They did a GREAT JOB! They did it in record time! SAME DAY! and they had the best price!",
      "person":"Daniel G. in Berkeley",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:p_ACaAus6HYtZMpZf-7CFA"
   },
   {
      "review":"Honest and competitively priced",
      "person":"Barron L. on Yelp",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:BM667D1OpsijQlqf41QcQw"
   },
   {
      "review":"For the past two years, they've performed oil changes, minor/major scheduled maintenance, brake and rotor replacement and timing belt replacement.  They do a good job of explaining why they do what they do and often show you the old/worn part afterwards.  Depending on the job, they'll offer a range of parts to accommodate your budget (e.g. OEM vs. high-performance parts) and I've never felt I was being pressured to purchase anything I didn't want or need.",
      "person":"Barron L. on Yelp",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:BM667D1OpsijQlqf41QcQw"
   },
   {
      "review":"Worth the drive to have your Audi fixed right the first time, Naim and Ali are great!",
      "person":"Harris S. in Manteca",
      "url":"http://www.yelp.com/biz/auto-plus-albany#hrid:O1JdCUoHqjVGoYg6N_jLHA"
   },
   {
      "review":"Ali and Naeem are nice, friendly guys who know their Audi's. Good overall experience, and I'd recommend them to someone looking to get work done on their Audi.",
      "person":"Aurangzeb Agha",
      "url":"https://plus.google.com/118398897840050126332/reviews"
   },
   {
      "review":"This is a great garage. Ali the owner is wonderful. He provides great service. They have best prices I can find, and I always shop around even if I know I'll just wind up taking it to him. He usually changes my oil with out being asked to for larger jobs. I am really happy with them. Consistently great service. and I always check for better prices, he is always the best, and if he's not most cases he's willing to match the cost of a competitors labor.",
      "person":"Google review",
      "url":"https://plus.google.com/103793884028557646091/about"
   }
,
   {
      "review":"I'm a mechanical engineer who takes pleasure in knowing how things work & whay they sometimes don't. I've been bringing my cars to AutoPlus for a long time, and have had many very good experiences in tracking down sometimes inscrutable problems with Naim. He knows what he's doing. I trust him. He once solved a problem with the brake system on my daughter's car that had eluded twoVolkswagen service departments, Firestone & Goodyear! So it is almost like I owe him my daughters life! Hmmm. Sounds over the top . . . well, anyway, he is good.",
      "person":"Google review",
      "url":"https://plus.google.com/103793884028557646091/about"
   },
   {
      "review":"I was very nervous about taking my 2000 Audi A6 to a mechanic when it would not start. I was afraid I was not going to be able to afford the repairs and that the mechanic was going to take full advantage of me because I was woman. Let me tell you, my experience there was nothing like I imagined. The owner welcomed me to his shop, never made me feel pressured and on the contrary he eased all of my worries. I have NEVER met a mechanic so great with customer service. He went beyond what I ever imagined, gave me a great deal, fixed my car and it runs great! My daughter and I are very grateful to him for all that he did and he will for always be our mechanic!! Thank you Auto Plus!!!!",
      "person":"Google review",
      "url":"https://plus.google.com/103793884028557646091/about"
   },
   {
      "review":"Repairing aVolkswagen or Audi is not cheap. But Ali and Naim went out of their way to find the best price on some crazy expensive replacement parts for myVolkswagen. Thanks guys.",
      "person":"Google review",
      "url":"https://plus.google.com/103793884028557646091/about"
   },
   {
      "review":"I been to many repair shop in the Bay Area. Most of them either cost through the roof or their services are not up to par. Autoplus is one of the most reliable I've been too. I would recommeneded anyone who needs any kind of work done to there vehicle to go see them the two brothers treat you like family!",
      "person":"Google review",
      "url":"https://plus.google.com/103793884028557646091/about"
   },
   {
      "review":"The best service ever. Just want to assure anyone that if they need any maintenance done to there car Auto Plus is the place to go. I brought my car in for a major service and the customer service and work was amazing. I had my car back by the next day and it was half the cost of what the dealer wanted. Thanks to all the guys at Auto Plus!",
      "person":"Yellowpages review",
      "url":"http://www.yellowpages.com/albany-ca/mip/auto-plus-12582201"
   },
   {
      "review":"Honest and Affordable. I have been taking myVolkswagen to Auto Plus for the past 7 years. I am very satisfied with their work and prices. I always get my car back on time as promised. I don't worry about my car anymore because I know they look after it and let me know if it needs anything. I don't have to worry about calling around other shops to make sure they are not ripping me off. ",
      "person":"Yellowpages review",
      "url":"http://www.yellowpages.com/albany-ca/mip/auto-plus-12582201"
   },
   {
      "review":"A very satisfied customer.  We have three not so new cars that require regular maintenance. I was so tired of taking the cars for a small problem to other shops where they would renew many other unnecessary parts and keep the car for days costing us a fortune. We were lucky to finally find an honest mechanic who don’t rip us off and are good at what they do. We have been taking our cars there for years without any complaint. ",
      "person":"Yellowpages review",
      "url":"http://www.yellowpages.com/albany-ca/mip/auto-plus-12582201"
   },
   {
      "review":"Star quality. These guys are very knowledgeable. After several frustrating attempt to have my Saab serviced. These guys were referred to me by a Saab owner. Although they don't specialize in servicing Saab's they made an exception in my case and did an exceptional job every time I was serviced there. They also provided several referrals for other services I need. Try them you'll like them :)",
      "person":"Yellowpages review",
      "url":"http://www.yellowpages.com/albany-ca/mip/auto-plus-12582201"
   },
   {
      "review":"Simply the best. I have been going to Auto Plus for the past 4 years and my car always runs better after they have worked their magic. They have served me well for both major and minor repairs, everything from shocks, timing belt, tire issues, brakes, you name it. I have such faith in Naim (sp?) and his crew that I recommend him to family and friends. They all agree with me that he is one of the most trustworthy, affordable mechanics out there. I really appreciate that he never tries to make me spend more than I have to. For example, he'll let me know if my brakes will last another year before having to be replaced. Also, he's always doing freebies like topping off my power steering and giving me free oil changes when I am having other major repairs done too. I once popped by with a deflated tire...he sealed it...pumped it up and sent me on my merry way free of charge. ",
      "person":"Yahoo! review",
      "url":"http://local.yahoo.com/info-21504890-vw-and-audi-repair-berkeley-albany"
   },
   {
      "review":"Simply the best. I have been going to Auto Plus for the past 4 years and my car always runs better after they have worked their magic. They have served me well for both major and minor repairs, everything from shocks, timing belt, tire issues, brakes, you name it. I have such faith in Naim (sp?) and his crew that I recommend him to family and friends. They all agree with me that he is one of the most trustworthy, affordable mechanics out there. I really appreciate that he never tries to make me spend more than I have to. For example, he'll let me know if my brakes will last another year before having to be replaced. Also, he's always doing freebies like topping off my power steering and giving me free oil changes when I am having other major repairs done too. I once popped by with a deflated tire...he sealed it...pumped it up and sent me on my merry way free of charge. ",
      "person":"Trinh on Yahoo!",
      "url":"http://local.yahoo.com/info-21504890-vw-and-audi-repair-berkeley-albany"
   },
   {
      "review":"I have been bringing my car to Auto Plus for about 5 years now. Their prices are reasonable, they are friendly and easy to work with and they know what they are doing. I have recommended them to my family and all my friends and they are very happy with them. They are also conveniently located. I live around Berkeley and work in SF. I usually drop my car in the morning and they drive me to the El Cerrito Bart or if I come for a quick oil change, I don’t even make an appointment. I just drop my car and walk to El Cerrito Plaza and shop there while they work on my car. ",
      "person":"Madina on Yahoo!",
      "url":"http://local.yahoo.com/info-21504890-vw-and-audi-repair-berkeley-albany"
   },
   {
      "review":"I've been a satisfied customer of Auto Plus for over 6 years. My first car was a Honda Civic DX, 1997, and I've done all my services and upgrades there until the time I sold the car in a perfect condition. The two brothers that run the store are very helpful, and gives the lowest estimates in the town. I now drive a customized 06 Mustang, and trust me, I am pretty saavy with it comes to getting the lowest price on car services and upgrades. While all the neighboring auto shops over charges you for bunch of BS* inspections, AutoPlus inspected my car free of charge, and gave me all the best options for my repairs. I've taken all four of my family cars (Honda Accord, Toyota Camry, Infinity QX4, and Ford mustang) there for services and repairs for the past 5 years, and I am pretty sure I've saved over $5000 easily. The turn around time on your cars are also very fast, and you don't really need to make appointments most of the time. You can just call them up, and they'll take care of you right away. So, If your looking to Save $$$ and wants someone whose honest and straightforward about the damages, I highly recommend that you give AUTO PLUS a call. ",
      "person":"Tenzin on Yahoo!",
      "url":"http://local.yahoo.com/info-21504890-vw-and-audi-repair-berkeley-albany"
   },
   {
      "review":"Five stars for Auto Plus... A recent experience has strengthened my 21 year long good-maintence-memories and continuing partnership with auto mechanic Naim of Auto Plus. I towed my physically challenged Volkswagon Van to a new shop due a recent residential move which is 20 miles away from my old faithful mechanic/shop - Auto Plus. It was the Wednesday before Thanksgiving 2008 when I towed myVolkswagen to the 'new shop' - Bud's Auto in Castro Valley... An estimate was given to me of $920.00 to fix the axle and wheel bearing-(thing a magiggy). A feeling of nervousness came over me realizing the exorbitant amount requested by Bud's. The panic soon ceased after calling my friend/mechanic Naim for advice. Hearing his kind, calm voice was reassuring. I asked him to call Bud's to determine the need, resulting in his return call to me and estimate of $500. The fair sounding price prompted me to call AAA again for a second tow to Albany - Auto Plus on San Pablo Av. Bud's charged me $119.00 for the diagnostic check and I paid it and the add'l tow, because I felt better bringing our wheels to our reliable friend. The actual cost of the repair turned out to be $295.00! The job was done on the same day as the tow, (a Friday) which was an added plus,(as Bud's was going to take 'til Tuesday just to order the parts). I have been very content with the service of my acquaintences, as previously stated for 21 years. The owners/brothers used to be located on a larger/more charming spot on Gilman st. in Berkeley (formerly, Gilman Imports). They moved around 8 years ago to their present location which is on the busier San Pablo av. and I too followed. The little shop is worth visiting as the charm is in the owners. I have experienced quality, efficiency and a caring family providing honest repair on my Volkswagen and my previously owned Mercedes. Often you will walk in to a shop filled with Sonorous classical music or BBC news and green tea brewing in a pot. They repair various makes and models. Give them a call...Naim always answers.",
      "person":"Becca on Yahoo!",
      "url":"http://local.yahoo.com/info-21504890-vw-and-audi-repair-berkeley-albany"
   },{
      "review":"A recent experience has strengthened my 21 year long good-maintence-memories and continuing partnership with auto mechanic Naim of Auto Plus.",
      "person":"Becca on Yahoo!",
      "url":"http://local.yahoo.com/info-21504890-vw-and-audi-repair-berkeley-albany"
   },
{
      "review":"Give them a call...Naim always answers.",
      "person":"Becca on Yahoo!",
      "url":"http://local.yahoo.com/info-21504890-vw-and-audi-repair-berkeley-albany"
   },
{
      "review":"The little shop is worth visiting as the charm is in the owners. I have experienced quality, efficiency and a caring family providing honest repair on my Volkswagen and my previously owned Mercedes. Often you will walk in to a shop filled with Sonorous classical music or BBC news and green tea brewing in a pot. They repair various makes and models. Give them a call...Naim always answers.",
      "person":"Becca on Yahoo!",
      "url":"http://local.yahoo.com/info-21504890-vw-and-audi-repair-berkeley-albany"
   },
{
      "review":"Caring family providing honest repair",
      "person":"Becca on Yahoo!",
      "url":"http://local.yahoo.com/info-21504890-vw-and-audi-repair-berkeley-albany"
   },
   {
      "review":"I wanted to upgrade my turbo from a ko3 to ko4 on my Audi A4. I went to Auto Plus and got an estimate of less than half of what Griffin and other Audi specialists gave me. The job was done perfectly and i got the price I wanted. I highly recommend Auto Plus for all audi owners.",
      "person":"Yahoo! review",
      "url":"http://local.yahoo.com/info-21504890-vw-and-audi-repair-berkeley-albany"
   },{
      "review":"I highly recommend Auto Plus for all audi owners.",
      "person":"Yahoo! review",
      "url":"http://local.yahoo.com/info-21504890-vw-and-audi-repair-berkeley-albany"
   },
];



item = {
      "review":"I wanted to upgrade my turbo from a ko3 to ko4 on my Audi A4. I went to Auto Plus and got an estimate of less than half of what Griffin and other Audi specialists gave me. The job was done perfectly and i got the price I wanted. I highly recommend Auto Plus for all audi owners.",
      "person":"Yahoo! review",
      "url":"http://local.yahoo.com/info-21504890-vw-and-audi-repair-berkeley-albany"
   };

var shortreviews = $.grep(reviews, function(v) {
    return v.review.length > 20 && v.review.length < 40;
});

var random = Math.floor(Math.random()*6);

item = shortreviews[random];

$("#ReviewArea #review #text").html('"'+item.review+'"');
$("#ReviewArea #review #name").html(item.person);
$("#ReviewArea #review").attr("href",item.url);
